# OLMS AWS Migration - Deployment Guide

## Prerequisites

Before deploying the OLMS AWS migration, ensure you have the following prerequisites:

### Required Software
- AWS CLI (version 2.0 or later)
- Terraform (version 1.0 or later)
- Git
- Bash shell (Linux/macOS/WSL)

### AWS Account Setup
1. AWS account with appropriate permissions
2. AWS CLI configured with credentials
3. Sufficient service limits for the deployment

### Required AWS Permissions
The deployment requires the following AWS permissions:
- EC2: Full access for instances, security groups, load balancers
- RDS: Full access for database creation and management
- VPC: Full access for networking components
- IAM: Permissions to create roles and policies
- CloudWatch: Full access for monitoring and logging
- CloudTrail: Permissions for audit logging
- Secrets Manager: Full access for credential management
- WAF: Permissions for web application firewall

## Step-by-Step Deployment

### 1. Environment Preparation

```bash
# Clone the repository
git clone <repository-url>
cd olms-aws-migration

# Verify prerequisites
aws --version
terraform --version
```

### 2. AWS Configuration

```bash
# Configure AWS CLI (if not already done)
aws configure

# Verify AWS access
aws sts get-caller-identity
```

### 3. Create SSH Key Pair

```bash
# Create key pair in AWS (replace 'us-east-1' with your region)
aws ec2 create-key-pair --key-name olms-keypair --query 'KeyMaterial' --output text > olms-keypair.pem
chmod 400 olms-keypair.pem
```

### 4. Configure Terraform Variables

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars

# Edit terraform.tfvars with your specific values
nano terraform.tfvars
```

Required variables to customize:
- `aws_region`: Your preferred AWS region
- `key_name`: Name of your SSH key pair
- `allowed_cidr_blocks`: IP ranges allowed to access the application
- `project_name`: Customize if desired
- `environment`: Customize if desired

### 5. Deploy Infrastructure

#### Option A: Automated Deployment (Recommended)
```bash
# Return to project root
cd ..

# Run automated deployment script
./application/scripts/deploy.sh
```

#### Option B: Manual Deployment
```bash
cd terraform

# Initialize Terraform
terraform init

# Review deployment plan
terraform plan

# Apply configuration
terraform apply
```

### 6. Verify Deployment

```bash
# Check Terraform outputs
cd terraform
terraform output

# Test application accessibility
curl -I https://$(terraform output -raw alb_dns_name)
```

### 7. Run Security Validation

```bash
# Return to project root
cd ..

# Run comprehensive security validation
./application/scripts/security_validation.sh

# Run penetration testing
./application/scripts/pentest.sh
```

## Post-Deployment Configuration

### 1. Access the Application

The application will be available at the ALB DNS name shown in Terraform outputs:
```bash
terraform output alb_dns_name
```

### 2. Default Credentials

- **Admin Username**: admin
- **Admin Password**: admin123
- **Student Username**: STU001
- **Student Password**: password

**Important**: Change default passwords immediately after first login.

### 3. SSL Certificate

The deployment creates a self-signed certificate. For production use:
1. Obtain a valid SSL certificate
2. Update the ALB listener configuration
3. Configure proper domain name

## Monitoring and Maintenance

### CloudWatch Dashboards

Access monitoring dashboards:
1. Go to AWS CloudWatch console
2. Navigate to Dashboards
3. Select the OLMS dashboard

### Log Analysis

View application logs:
1. Go to CloudWatch Logs
2. Check log groups:
   - `/aws/ec2/olms/apache/access`
   - `/aws/ec2/olms/apache/error`

### Security Monitoring

Monitor security events:
1. CloudTrail logs in S3
2. CloudWatch security alarms
3. WAF blocked requests

## Troubleshooting

### Common Issues

#### Deployment Fails
1. Check AWS credentials and permissions
2. Verify service limits in your AWS account
3. Check Terraform error messages
4. Ensure unique resource names

#### Application Not Accessible
1. Check Security Group configurations
2. Verify ALB health checks
3. Check EC2 instance status
4. Review application logs

#### Database Connection Issues
1. Verify RDS instance status
2. Check Security Group rules
3. Validate Secrets Manager configuration
4. Review database logs

### Getting Help

1. Check CloudWatch logs for error messages
2. Review Terraform state and outputs
3. Validate AWS resource configurations
4. Check security group and network ACL rules

## Scaling and Optimization

### Auto Scaling Configuration

The deployment includes auto scaling based on:
- CPU utilization (scale up at 80%, scale down at 10%)
- Health check failures
- Custom metrics (if configured)

### Performance Optimization

1. Monitor CloudWatch metrics
2. Adjust instance types based on usage
3. Optimize database parameters
4. Configure caching if needed

### Cost Optimization

1. Review instance utilization
2. Consider Reserved Instances for predictable workloads
3. Implement lifecycle policies for logs and backups
4. Monitor and optimize data transfer costs

## Security Best Practices

### Ongoing Security

1. Regularly update AMIs with security patches
2. Monitor security alerts and respond promptly
3. Review and rotate credentials regularly
4. Conduct periodic security assessments

### Access Management

1. Use least privilege principles for all access
2. Enable MFA for administrative accounts
3. Regular access reviews and cleanup
4. Monitor and log all administrative actions

### Data Protection

1. Verify encryption is working correctly
2. Test backup and recovery procedures
3. Monitor data access patterns
4. Implement data retention policies

## Cleanup

To remove all resources and avoid ongoing charges:

```bash
# Using the cleanup script
./application/scripts/deploy.sh cleanup

# Or manually with Terraform
cd terraform
terraform destroy
```

**Warning**: This will permanently delete all data and resources. Ensure you have backups if needed.

## Support

For issues or questions:
1. Review this deployment guide
2. Check the main project documentation
3. Review AWS service documentation
4. Check Terraform provider documentation

---

**Note**: This deployment guide is for educational purposes. Ensure proper security review and testing before using in production environments.

