# OLMS AWS Migration Project

## Overview

This repository contains the complete implementation of the Online Library Management System (OLMS) migration from a traditional on-premises architecture to a secure, scalable AWS cloud-native environment. This project was developed as part of Assignment 2 for the Database & Cloud Security course (CCS6344 T2510).

## Project Structure

```
olms-aws-migration/
├── README.md                          # This file
├── docs/                              # Documentation
│   ├── final_report.md               # Complete project report
│   ├── aws_architecture_diagram.png   # AWS architecture diagram
│   └── security_validation_results.png # Security testing results
├── terraform/                         # Infrastructure as Code
│   ├── main.tf                       # Main Terraform configuration
│   ├── variables.tf                  # Variable definitions
│   ├── outputs.tf                    # Output definitions
│   └── modules/                      # Terraform modules
│       ├── vpc/                      # VPC networking module
│       ├── security/                 # Security controls module
│       ├── rds/                      # Database module
│       ├── alb/                      # Load balancer module
│       ├── ec2/                      # Compute module
│       └── monitoring/               # Monitoring module
├── application/                       # Application code and scripts
│   ├── src/                          # Modified OLMS source code
│   ├── config/                       # AWS-specific configuration
│   └── scripts/                      # Deployment and testing scripts
│       ├── deploy.sh                 # Automated deployment
│       ├── migrate_database.sh       # Database migration
│       ├── security_validation.sh    # Security testing
│       └── pentest.sh               # Penetration testing
└── security_validation_results/      # Security test results
```

## Key Features

### Security Enhancements
- **Multi-layered Security**: Implements defense-in-depth with WAF, Security Groups, NACLs
- **Encryption**: End-to-end encryption for data at rest and in transit
- **Secrets Management**: AWS Secrets Manager for secure credential handling
- **Network Segmentation**: VPC with public/private subnets across multiple AZs
- **Comprehensive Monitoring**: CloudWatch and CloudTrail for security and operational visibility

### High Availability & Scalability
- **Multi-AZ Deployment**: Eliminates single points of failure
- **Auto Scaling**: Automatic capacity adjustment based on demand
- **Load Balancing**: Application Load Balancer with health checks
- **Database HA**: RDS Multi-AZ with automated failover

### Operational Excellence
- **Infrastructure as Code**: Complete Terraform implementation
- **Automated Deployment**: One-click deployment scripts
- **Monitoring & Alerting**: Real-time operational visibility
- **Backup & Recovery**: Automated backup with point-in-time recovery

## Quick Start

### Prerequisites
- AWS CLI configured with appropriate credentials
- Terraform installed (version 1.0+)
- Bash shell environment

### Deployment Steps

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd olms-aws-migration
   ```

2. **Configure variables**
   ```bash
   cd terraform
   cp terraform.tfvars.example terraform.tfvars
   # Edit terraform.tfvars with your specific values
   ```

3. **Deploy infrastructure**
   ```bash
   ./application/scripts/deploy.sh
   ```

4. **Validate security**
   ```bash
   ./application/scripts/security_validation.sh
   ```

### Manual Deployment

If you prefer manual deployment:

```bash
cd terraform
terraform init
terraform plan
terraform apply
```

## Security Validation

The project includes comprehensive security testing scripts:

- **Port Scanning**: Validates only expected ports are accessible
- **WAF Testing**: Confirms protection against common web attacks
- **SSL/TLS Validation**: Ensures proper encryption configuration
- **Database Security**: Verifies encryption and access controls
- **Penetration Testing**: Automated security vulnerability assessment

Run security validation:
```bash
./application/scripts/security_validation.sh
./application/scripts/pentest.sh
```

## Architecture Overview

The AWS architecture implements:

- **VPC**: Custom VPC with public/private subnets across 2 AZs
- **ALB**: Application Load Balancer with SSL termination
- **EC2**: Auto Scaling Group with custom AMIs
- **RDS**: MySQL database with Multi-AZ and encryption
- **WAF**: Web Application Firewall protection
- **CloudWatch**: Comprehensive monitoring and alerting
- **CloudTrail**: Complete audit logging
- **Secrets Manager**: Secure credential management

## Security Improvements

This migration addresses 7 critical security risks:

1. **Single Point of Failure** → Multi-AZ high availability
2. **Network Vulnerabilities** → Comprehensive network segmentation
3. **Component Management** → Managed AWS services with auto-patching
4. **Backup Deficiencies** → Automated encrypted backups
5. **Limited Monitoring** → Centralized logging and real-time alerting
6. **Insecure Secrets** → AWS Secrets Manager integration
7. **Web Vulnerabilities** → AWS WAF and Shield protection

## Documentation

- **Complete Report**: `docs/final_report.md` - Comprehensive project documentation
- **Architecture Diagrams**: Visual representations of the AWS architecture
- **Security Results**: Detailed security validation and testing results
- **Deployment Guide**: Step-by-step deployment instructions

## Testing

The project includes automated testing for:
- Infrastructure deployment validation
- Security control verification
- Application functionality testing
- Performance and scalability validation

## Compliance

The implementation addresses:
- OWASP Top 10 security requirements
- AWS Well-Architected Framework principles
- Educational data protection standards
- Audit and compliance logging requirements

## Support and Maintenance

### Monitoring
- CloudWatch dashboards for operational visibility
- Automated alerting for critical events
- Performance metrics and optimization recommendations

### Updates
- Automated security patching for managed services
- Infrastructure updates through Terraform
- Application updates through blue-green deployment

### Backup and Recovery
- Automated daily backups with 7-day retention
- Point-in-time recovery capabilities
- Cross-region backup replication for disaster recovery

## Cost Optimization

The architecture includes:
- Right-sized instances based on workload requirements
- Auto Scaling to optimize resource utilization
- Reserved Instance recommendations for predictable workloads
- Monitoring and alerting for cost optimization opportunities

## Contributing

This project was developed for academic purposes. For questions or improvements:

1. Review the documentation in `docs/`
2. Check existing issues and solutions
3. Follow AWS security best practices for any modifications
4. Test thoroughly in development environment before production changes

## License

This project is developed for educational purposes as part of the Database & Cloud Security course assignment.

## Authors

- **Group 04 Members:**
  - ALSILLAK ALI AHMED ALI (1211306219)
  - MEERAA DHARSINI (1211112118)
  - PEERRMETHA ELATCHAN (1211112117)

## Acknowledgments

- AWS documentation and best practices
- OWASP security guidelines
- Course instructors and materials
- Open source tools and libraries used in the implementation

---

**Note**: This is an academic project. Ensure proper security review and testing before using in production environments.

