<?php
session_start();
error_reporting(0);
include('includes/config.php');

// Redirect if not logged in
if(strlen($_SESSION['login']) == 0) {
    header('location:index.php');
    exit;
}

// Step 1: Lookup internal student ID from session StudentID
$studentCode = $_SESSION['stdid'];
$lookup = $dbh->prepare("SELECT id FROM tblstudents WHERE StudentID = :sid");
$lookup->bindParam(':sid', $studentCode, PDO::PARAM_STR);
$lookup->execute();
$student = $lookup->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $_SESSION['error'] = "Student not found.";
    header('location:index.php');
    exit;
}

$studentId = $student['id']; // internal DB FK
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Online Library Management System | Student Dashboard</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>

<?php include('includes/header.php');?>

<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">STUDENT DASHBOARD</h4>
            </div>
        </div>

        <div class="row">
            <!-- Issued Books -->
            <div class="col-md-3 col-sm-3 col-xs-6">
                <div class="alert alert-info back-widget-set text-center">
                    <i class="fa fa-bars fa-5x"></i>
<?php 
$sql1 = "SELECT id FROM tblissuedbookdetails WHERE StudentID = :sid";
$query1 = $dbh->prepare($sql1);
$query1->bindParam(':sid', $studentId, PDO::PARAM_INT);
$query1->execute();
$results1 = $query1->fetchAll(PDO::FETCH_OBJ);
$issuedbooks = count($results1);
?>
                    <h3><?php echo htmlentities($issuedbooks); ?></h3>
                    Book Issued
                </div>
            </div>

            <!-- Books Not Returned -->
            <div class="col-md-3 col-sm-3 col-xs-6">
                <div class="alert alert-warning back-widget-set text-center">
                    <i class="fa fa-recycle fa-5x"></i>
<?php 
$rsts = 0;
$sql2 = "SELECT id FROM tblissuedbookdetails WHERE StudentID = :sid AND RetrunStatus = :rsts";
$query2 = $dbh->prepare($sql2);
$query2->bindParam(':sid', $studentId, PDO::PARAM_INT);
$query2->bindParam(':rsts', $rsts, PDO::PARAM_INT);
$query2->execute();
$results2 = $query2->fetchAll(PDO::FETCH_OBJ);
$returnedbooks = count($results2);
?>
                    <h3><?php echo htmlentities($returnedbooks); ?></h3>
                    Books Not Returned Yet
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php');?>

<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>
