<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('includes/config.php');

if (strlen($_SESSION['alogin']) == 0) {
    header('location:index.php');
    exit;
}

if (isset($_POST['issue'])) {
    $studentcode = strtoupper(trim($_POST['studentid']));
    $bookid = trim($_POST['bookdetails']);  // ID from dropdown

    if (empty($studentcode) || empty($bookid) || !is_numeric($bookid)) {
        $_SESSION['error'] = "Invalid student ID or book selection.";
        header('location:manage-issued-books.php');
        exit;
    }

    try {
        // Step 1: Map student code to ID
        $stmt = $dbh->prepare("SELECT id FROM tblstudents WHERE StudentID = :studentcode");
        $stmt->bindParam(':studentcode', $studentcode, PDO::PARAM_STR);
        $stmt->execute();
        $student = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$student) {
            $_SESSION['error'] = "Student ID not found.";
            header('location:manage-issued-books.php');
            exit;
        }

        $studentid = (int)$student['id'];
        $bookid = (int)$bookid;

        // Step 2: Issue book
        $insert = $dbh->prepare("INSERT INTO tblissuedbookdetails (StudentID, BookID, IssuesDate, ReturnStatus)
                                 VALUES (:studentid, :bookid, GETDATE(), 0)");
        $insert->bindParam(':studentid', $studentid, PDO::PARAM_INT);
        $insert->bindParam(':bookid', $bookid, PDO::PARAM_INT);
        $insert->execute();

        $_SESSION['msg'] = "Book issued successfully.";
        header('location:manage-issued-books.php');
        exit;

    } catch (PDOException $e) {
        die("DB ERROR: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Online Library Management System | Issue a New Book</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <script>
        function getstudent() {
            $("#loaderIcon").show();
            jQuery.ajax({
                url: "get_student.php",
                data:'studentid='+$("#studentid").val(),
                type: "POST",
                success:function(data){
                    $("#get_student_name").html(data);
                    $("#loaderIcon").hide();
                },
                error:function (){}
            });
        }

        function getbook() {
            $("#loaderIcon").show();
            jQuery.ajax({
                url: "get_book.php",
                data:'bookid='+$("#bookid").val(),
                type: "POST",
                success:function(data){
                    $("#get_book_name").html(data);
                    $("#loaderIcon").hide();
                },
                error:function (){}
            });
        }
    </script>
    <style>
        .others {
            color: red;
        }
    </style>
</head>
<body>
<?php include('includes/header.php'); ?>
<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Issue a New Book</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 col-sm-6 col-xs-12 col-md-offset-1">
                <div class="panel panel-info">
                    <div class="panel-heading">Issue a New Book</div>
                    <div class="panel-body">
                        <form method="post">
                            <div class="form-group">
                                <label>Student ID <span style="color:red;">*</span></label>
                                <input class="form-control" type="text" name="studentid" id="studentid" onBlur="getstudent()" autocomplete="off" required />
                            </div>
                            <div class="form-group">
                                <span id="get_student_name" style="font-size:16px;"></span> 
                            </div>
                            <div class="form-group">
                                <label>ISBN Number or Book Title <span style="color:red;">*</span></label>
                                <input class="form-control" type="text" name="bookid" id="bookid" onBlur="getbook()" required />
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="bookdetails" id="get_book_name" required>
                                    <option value="">Select a book...</option>
                                </select>
                            </div>
                            <button type="submit" name="issue" class="btn btn-info">Issue Book</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/custom.js"></script>
</body>
</html>
