   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2018 Online Library Management System |<a href="https://www.linkedin.com/in/aleksandart96/" target="_blank"  > Designed by : Aleksandar Trifunovic</a> 
                </div>

            </div>
        </div>
    </section>
