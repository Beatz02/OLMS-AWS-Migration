<?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','library');
// Establish database connection.
try {
    $dbh = new PDO("sqlsrv:Server=localhost\\SQLEXPRESS;Database=bbts_db", "sa", "beatz0915653809");
    // echo "✅ Connected successfully to MSSQL!"; // optional
} catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}
?>