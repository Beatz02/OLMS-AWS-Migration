<?php
// DB credentials.
define('DB_HOST','localhost\\SQLEXPRESS');
define('DB_USER','sa');
define('DB_PASS','beatz0915653809');
define('DB_NAME','bbts_db');

// Establish database connection.
try {
    $dbh = new PDO("sqlsrv:Server=localhost\\SQLEXPRESS;Database=bbts_db", "sa", "beatz0915653809");
    // echo "✅ Connected successfully to MSSQL!"; // optional
} catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}
?>
