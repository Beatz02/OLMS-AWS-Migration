<?php
// DB credentials
define('DB_HOST','localhost');
define('DB_USER','bbts_user');
define('DB_PASS','bbts123');
define('DB_NAME','bbts_db');

// Establish database connection
try {
    $dbh = new PDO("sqlsrv:Server=".DB_HOST.";Database=".DB_NAME, DB_USER, DB_PASS);
} catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}
?>
