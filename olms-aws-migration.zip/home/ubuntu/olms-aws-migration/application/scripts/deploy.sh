#!/bin/bash
# Deployment script for OLMS on AWS
# This script deploys the OLMS application using Terraform

set -e

# Configuration
PROJECT_DIR="/home/ubuntu/olms-aws-migration"
TERRAFORM_DIR="$PROJECT_DIR/terraform"
APPLICATION_DIR="$PROJECT_DIR/application"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check if AWS CLI is installed and configured
    if ! command -v aws &> /dev/null; then
        print_error "AWS CLI is not installed. Please install it first."
        exit 1
    fi
    
    # Check AWS credentials
    if ! aws sts get-caller-identity &> /dev/null; then
        print_error "AWS credentials not configured. Please run 'aws configure'."
        exit 1
    fi
    
    # Check if Terraform is installed
    if ! command -v terraform &> /dev/null; then
        print_error "Terraform is not installed. Please install it first."
        exit 1
    fi
    
    print_status "Prerequisites check passed!"
}

# Function to create SSH key pair
create_key_pair() {
    print_status "Creating SSH key pair..."
    
    KEY_NAME="olms-keypair"
    
    # Check if key pair already exists
    if aws ec2 describe-key-pairs --key-names "$KEY_NAME" &> /dev/null; then
        print_warning "Key pair '$KEY_NAME' already exists. Skipping creation."
        return
    fi
    
    # Create key pair
    aws ec2 create-key-pair --key-name "$KEY_NAME" --query 'KeyMaterial' --output text > "$PROJECT_DIR/$KEY_NAME.pem"
    chmod 400 "$PROJECT_DIR/$KEY_NAME.pem"
    
    print_status "SSH key pair created: $PROJECT_DIR/$KEY_NAME.pem"
}

# Function to deploy infrastructure
deploy_infrastructure() {
    print_status "Deploying infrastructure with Terraform..."
    
    cd "$TERRAFORM_DIR"
    
    # Initialize Terraform
    print_status "Initializing Terraform..."
    terraform init
    
    # Validate configuration
    print_status "Validating Terraform configuration..."
    terraform validate
    
    # Plan deployment
    print_status "Planning Terraform deployment..."
    terraform plan -out=tfplan
    
    # Apply deployment
    print_status "Applying Terraform deployment..."
    terraform apply tfplan
    
    # Save outputs
    terraform output > "$PROJECT_DIR/terraform_outputs.txt"
    
    print_status "Infrastructure deployment completed!"
}

# Function to wait for instances to be ready
wait_for_instances() {
    print_status "Waiting for EC2 instances to be ready..."
    
    # Get Auto Scaling Group name from Terraform output
    ASG_NAME=$(terraform output -raw autoscaling_group_name 2>/dev/null || echo "")
    
    if [ -z "$ASG_NAME" ]; then
        print_warning "Could not get Auto Scaling Group name. Waiting 5 minutes..."
        sleep 300
        return
    fi
    
    # Wait for instances to be in service
    aws autoscaling wait instance-in-service --auto-scaling-group-name "$ASG_NAME"
    
    print_status "EC2 instances are ready!"
}

# Function to test deployment
test_deployment() {
    print_status "Testing deployment..."
    
    cd "$TERRAFORM_DIR"
    
    # Get ALB DNS name
    ALB_DNS=$(terraform output -raw alb_dns_name 2>/dev/null || echo "")
    
    if [ -z "$ALB_DNS" ]; then
        print_error "Could not get ALB DNS name from Terraform output."
        return 1
    fi
    
    print_status "ALB DNS Name: $ALB_DNS"
    print_status "Testing HTTP redirect to HTTPS..."
    
    # Test HTTP redirect
    HTTP_RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" "http://$ALB_DNS" || echo "000")
    
    if [ "$HTTP_RESPONSE" = "301" ] || [ "$HTTP_RESPONSE" = "302" ]; then
        print_status "HTTP redirect working correctly (Status: $HTTP_RESPONSE)"
    else
        print_warning "HTTP redirect may not be working (Status: $HTTP_RESPONSE)"
    fi
    
    # Test HTTPS (with self-signed certificate)
    print_status "Testing HTTPS endpoint..."
    HTTPS_RESPONSE=$(curl -s -k -o /dev/null -w "%{http_code}" "https://$ALB_DNS" || echo "000")
    
    if [ "$HTTPS_RESPONSE" = "200" ]; then
        print_status "HTTPS endpoint working correctly (Status: $HTTPS_RESPONSE)"
    else
        print_warning "HTTPS endpoint may not be ready yet (Status: $HTTPS_RESPONSE)"
        print_warning "It may take a few minutes for the application to be fully deployed."
    fi
    
    print_status "Application URL: https://$ALB_DNS"
}

# Function to show deployment summary
show_summary() {
    print_status "Deployment Summary"
    echo "===================="
    
    cd "$TERRAFORM_DIR"
    
    echo "VPC ID: $(terraform output -raw vpc_id 2>/dev/null || echo 'N/A')"
    echo "ALB DNS: $(terraform output -raw alb_dns_name 2>/dev/null || echo 'N/A')"
    echo "Database Endpoint: $(terraform output -raw db_endpoint 2>/dev/null || echo 'N/A')"
    echo "SSH Key: $PROJECT_DIR/olms-keypair.pem"
    
    echo ""
    print_status "Next Steps:"
    echo "1. Wait a few minutes for the application to fully initialize"
    echo "2. Access the application at: https://$(terraform output -raw alb_dns_name 2>/dev/null || echo 'ALB_DNS')"
    echo "3. Default admin credentials: admin/admin123"
    echo "4. Monitor the deployment in AWS CloudWatch"
}

# Function to cleanup (for development/testing)
cleanup() {
    print_warning "This will destroy all AWS resources created by this deployment."
    read -p "Are you sure you want to continue? (yes/no): " confirm
    
    if [ "$confirm" = "yes" ]; then
        cd "$TERRAFORM_DIR"
        terraform destroy -auto-approve
        
        # Delete key pair
        aws ec2 delete-key-pair --key-name "olms-keypair" || true
        rm -f "$PROJECT_DIR/olms-keypair.pem"
        
        print_status "Cleanup completed!"
    else
        print_status "Cleanup cancelled."
    fi
}

# Main function
main() {
    case "${1:-deploy}" in
        "deploy")
            check_prerequisites
            create_key_pair
            deploy_infrastructure
            wait_for_instances
            test_deployment
            show_summary
            ;;
        "test")
            test_deployment
            ;;
        "cleanup")
            cleanup
            ;;
        "destroy")
            cleanup
            ;;
        *)
            echo "Usage: $0 [deploy|test|cleanup|destroy]"
            echo "  deploy  - Deploy the complete infrastructure (default)"
            echo "  test    - Test the deployed application"
            echo "  cleanup - Destroy all AWS resources"
            echo "  destroy - Same as cleanup"
            exit 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"

