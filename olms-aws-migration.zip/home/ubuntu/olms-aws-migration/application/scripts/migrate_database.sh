#!/bin/bash
# Database migration script for OLMS
# This script migrates data from SQL Server to MySQL format

set -e

# Configuration
DB_HOST="${1:-localhost}"
DB_USER="${2:-admin}"
DB_PASS="${3:-password}"
DB_NAME="${4:-olmsdb}"

echo "Starting OLMS database migration..."

# Create SQL file for MySQL schema
cat > /tmp/olms_mysql_schema.sql << 'EOF'
-- OLMS Database Schema for MySQL
-- Migrated from SQL Server to MySQL

USE olmsdb;

-- Create admin table
CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    AdminEmail VARCHAR(120) NOT NULL UNIQUE,
    UserName VARCHAR(100) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    updationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create tblcategory table
CREATE TABLE IF NOT EXISTS tblcategory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(150) NOT NULL,
    Status TINYINT(1) DEFAULT 1,
    CreationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create tblauthors table
CREATE TABLE IF NOT EXISTS tblauthors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    AuthorName VARCHAR(159) NOT NULL,
    creationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create tblbooks table
CREATE TABLE IF NOT EXISTS tblbooks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    BookName VARCHAR(255) NOT NULL,
    CatId INT NOT NULL,
    AuthorId INT NOT NULL,
    ISBNNumber VARCHAR(25) NOT NULL UNIQUE,
    BookPrice DECIMAL(10,2) NOT NULL,
    RegDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (CatId) REFERENCES tblcategory(id),
    FOREIGN KEY (AuthorId) REFERENCES tblauthors(id)
);

-- Create tblstudents table
CREATE TABLE IF NOT EXISTS tblstudents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    StudentId VARCHAR(100) NOT NULL UNIQUE,
    FullName VARCHAR(120) NOT NULL,
    EmailId VARCHAR(120) NOT NULL UNIQUE,
    MobileNumber CHAR(11) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Status TINYINT(1) DEFAULT 1,
    RegDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UpdationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create tblissuedbookdetails table
CREATE TABLE IF NOT EXISTS tblissuedbookdetails (
    id INT AUTO_INCREMENT PRIMARY KEY,
    BookId INT NOT NULL,
    StudentID VARCHAR(150) NOT NULL,
    IssuesDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ReturnDate TIMESTAMP NULL,
    ReturnStatus TINYINT(1) DEFAULT 0,
    fine DECIMAL(10,2) DEFAULT 0,
    FOREIGN KEY (BookId) REFERENCES tblbooks(id)
);

-- Insert sample data
INSERT IGNORE INTO admin (FullName, AdminEmail, UserName, Password) VALUES 
('Administrator', 'admin@olms.com', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

INSERT IGNORE INTO tblcategory (CategoryName, Status) VALUES 
('Technology', 1),
('Science', 1),
('Literature', 1),
('History', 1),
('Mathematics', 1);

INSERT IGNORE INTO tblauthors (AuthorName) VALUES 
('John Doe'),
('Jane Smith'),
('Robert Johnson'),
('Emily Davis'),
('Michael Brown');

INSERT IGNORE INTO tblbooks (BookName, CatId, AuthorId, ISBNNumber, BookPrice) VALUES 
('Introduction to Computer Science', 1, 1, '978-0123456789', 59.99),
('Advanced Physics', 2, 2, '978-0123456790', 79.99),
('Classic Literature', 3, 3, '978-0123456791', 39.99),
('World History', 4, 4, '978-0123456792', 49.99),
('Calculus and Analysis', 5, 5, '978-0123456793', 69.99);

INSERT IGNORE INTO tblstudents (StudentId, FullName, EmailId, MobileNumber, Password, Status) VALUES 
('STU001', 'Alice Johnson', 'alice@student.com', '12345678901', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1),
('STU002', 'Bob Wilson', 'bob@student.com', '12345678902', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1),
('STU003', 'Carol Davis', 'carol@student.com', '12345678903', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);

EOF

# Execute the SQL file
mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" < /tmp/olms_mysql_schema.sql

echo "Database migration completed successfully!"
echo "Default admin credentials: admin/admin123"
echo "Default student credentials: STU001/password"

# Clean up
rm -f /tmp/olms_mysql_schema.sql

