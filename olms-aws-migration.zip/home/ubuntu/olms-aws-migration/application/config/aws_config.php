<?php
// AWS-specific configuration for OLMS
// This file replaces the original config.php to work with AWS services

// Function to get database credentials from AWS Secrets Manager
function getDbCredentials() {
    $secretArn = getenv('DB_SECRET_ARN');
    $region = getenv('AWS_DEFAULT_REGION') ?: 'us-east-1';
    
    if (!$secretArn) {
        throw new Exception('DB_SECRET_ARN environment variable not set');
    }
    
    $cmd = "aws secretsmanager get-secret-value --secret-id '$secretArn' --region '$region' --output json 2>/dev/null";
    $output = shell_exec($cmd);
    
    if (!$output) {
        throw new Exception('Failed to execute AWS CLI command');
    }
    
    $result = json_decode($output, true);
    
    if ($result && isset($result['SecretString'])) {
        return json_decode($result['SecretString'], true);
    }
    
    throw new Exception('Failed to retrieve database credentials from Secrets Manager');
}

// Function to log errors to CloudWatch
function logError($message, $context = []) {
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'level' => 'ERROR',
        'message' => $message,
        'context' => $context,
        'server' => gethostname(),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ];
    
    error_log(json_encode($logEntry));
}

// Function to log security events
function logSecurityEvent($event, $details = []) {
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'event_type' => 'SECURITY',
        'event' => $event,
        'details' => $details,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'session_id' => session_id()
    ];
    
    error_log(json_encode($logEntry));
}

try {
    // Get database credentials from AWS Secrets Manager
    $dbCredentials = getDbCredentials();
    
    // Database configuration
    define('DB_HOST', getenv('DB_ENDPOINT'));
    define('DB_USER', $dbCredentials['username']);
    define('DB_PASS', $dbCredentials['password']);
    define('DB_NAME', 'olmsdb');
    
    // Convert SQL Server connection to MySQL for AWS RDS
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_SSL_CA       => '/opt/rds-ca-2019-root.pem', // RDS SSL certificate
        PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => false,
    ];
    
    // Establish database connection
    $dbh = new PDO($dsn, DB_USER, DB_PASS, $options);
    
    // Log successful connection (for monitoring)
    error_log("Database connection established successfully");
    
} catch (Exception $e) {
    logError("Database connection failed", [
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ]);
    
    // Don't expose sensitive information to users
    die("Database connection failed. Please try again later.");
}

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

// Session security configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

// Start session with security settings
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CSRF protection function
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Input sanitization function
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Rate limiting function (basic implementation)
function checkRateLimit($identifier, $maxRequests = 100, $timeWindow = 3600) {
    $key = "rate_limit_" . md5($identifier);
    $current = $_SESSION[$key] ?? ['count' => 0, 'start_time' => time()];
    
    if (time() - $current['start_time'] > $timeWindow) {
        $current = ['count' => 1, 'start_time' => time()];
    } else {
        $current['count']++;
    }
    
    $_SESSION[$key] = $current;
    
    if ($current['count'] > $maxRequests) {
        logSecurityEvent('RATE_LIMIT_EXCEEDED', [
            'identifier' => $identifier,
            'count' => $current['count'],
            'time_window' => $timeWindow
        ]);
        return false;
    }
    
    return true;
}

// Function to create database tables if they don't exist (MySQL version)
function createDatabaseTables() {
    global $dbh;
    
    try {
        // Create admin table
        $dbh->exec("CREATE TABLE IF NOT EXISTS admin (
            id INT AUTO_INCREMENT PRIMARY KEY,
            FullName VARCHAR(100) NOT NULL,
            AdminEmail VARCHAR(120) NOT NULL UNIQUE,
            UserName VARCHAR(100) NOT NULL UNIQUE,
            Password VARCHAR(255) NOT NULL,
            updationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        // Create tblcategory table
        $dbh->exec("CREATE TABLE IF NOT EXISTS tblcategory (
            id INT AUTO_INCREMENT PRIMARY KEY,
            CategoryName VARCHAR(150) NOT NULL,
            Status TINYINT(1) DEFAULT 1,
            CreationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UpdationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        // Create tblauthors table
        $dbh->exec("CREATE TABLE IF NOT EXISTS tblauthors (
            id INT AUTO_INCREMENT PRIMARY KEY,
            AuthorName VARCHAR(159) NOT NULL,
            creationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UpdationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        // Create tblbooks table
        $dbh->exec("CREATE TABLE IF NOT EXISTS tblbooks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            BookName VARCHAR(255) NOT NULL,
            CatId INT NOT NULL,
            AuthorId INT NOT NULL,
            ISBNNumber VARCHAR(25) NOT NULL UNIQUE,
            BookPrice DECIMAL(10,2) NOT NULL,
            RegDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UpdationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (CatId) REFERENCES tblcategory(id),
            FOREIGN KEY (AuthorId) REFERENCES tblauthors(id)
        )");
        
        // Create tblstudents table
        $dbh->exec("CREATE TABLE IF NOT EXISTS tblstudents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            StudentId VARCHAR(100) NOT NULL UNIQUE,
            FullName VARCHAR(120) NOT NULL,
            EmailId VARCHAR(120) NOT NULL UNIQUE,
            MobileNumber CHAR(11) NOT NULL,
            Password VARCHAR(255) NOT NULL,
            Status TINYINT(1) DEFAULT 1,
            RegDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UpdationDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        // Create tblissuedbookdetails table
        $dbh->exec("CREATE TABLE IF NOT EXISTS tblissuedbookdetails (
            id INT AUTO_INCREMENT PRIMARY KEY,
            BookId INT NOT NULL,
            StudentID VARCHAR(150) NOT NULL,
            IssuesDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            ReturnDate TIMESTAMP NULL,
            ReturnStatus TINYINT(1) DEFAULT 0,
            fine DECIMAL(10,2) DEFAULT 0,
            FOREIGN KEY (BookId) REFERENCES tblbooks(id)
        )");
        
        // Insert default admin user if not exists
        $stmt = $dbh->prepare("SELECT COUNT(*) FROM admin WHERE UserName = ?");
        $stmt->execute(['admin']);
        
        if ($stmt->fetchColumn() == 0) {
            $defaultPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $dbh->prepare("INSERT INTO admin (FullName, AdminEmail, UserName, Password) VALUES (?, ?, ?, ?)");
            $stmt->execute(['Administrator', 'admin@olms.com', 'admin', $defaultPassword]);
        }
        
        error_log("Database tables created/verified successfully");
        
    } catch (PDOException $e) {
        logError("Failed to create database tables", [
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]);
        throw $e;
    }
}

// Create tables on first run
createDatabaseTables();

// Application constants
define('SITE_URL', 'https://' . $_SERVER['HTTP_HOST']);
define('UPLOAD_PATH', '/var/www/html/olms/uploads/');
define('LOG_PATH', '/var/log/olms/');

// Ensure log directory exists
if (!is_dir(LOG_PATH)) {
    mkdir(LOG_PATH, 0755, true);
}
?>

