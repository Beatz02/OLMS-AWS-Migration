#!/bin/bash
# User data script for OLMS web servers
# This script installs and configures Apache, PHP, and the OLMS application

# Update system
yum update -y

# Install Apache, PHP, and required extensions
yum install -y httpd php php-mysqlnd php-json php-mbstring git aws-cli

# Install CloudWatch agent
yum install -y amazon-cloudwatch-agent

# Start and enable Apache
systemctl start httpd
systemctl enable httpd

# Create application directory
mkdir -p /var/www/html/olms

# Clone OLMS application (you would replace this with your actual repository)
cd /tmp
git clone https://github.com/your-repo/olms-aws.git
cp -r olms-aws/* /var/www/html/olms/

# Set proper permissions
chown -R apache:apache /var/www/html/olms
chmod -R 755 /var/www/html/olms

# Create PHP configuration file for database connection
cat > /var/www/html/olms/config/aws_config.php << 'EOF'
<?php
// AWS-specific configuration for OLMS

// Function to get database credentials from AWS Secrets Manager
function getDbCredentials() {
    $secretArn = '${db_secret_arn}';
    $region = 'us-east-1'; // Change this to your region
    
    $cmd = "aws secretsmanager get-secret-value --secret-id $secretArn --region $region --output json";
    $output = shell_exec($cmd);
    $result = json_decode($output, true);
    
    if ($result && isset($result['SecretString'])) {
        return json_decode($result['SecretString'], true);
    }
    
    throw new Exception('Failed to retrieve database credentials');
}

// Get database credentials
try {
    $dbCredentials = getDbCredentials();
    
    // Database configuration
    define('DB_HOST', '${db_endpoint}');
    define('DB_USER', $dbCredentials['username']);
    define('DB_PASS', $dbCredentials['password']);
    define('DB_NAME', 'olmsdb');
    
    // Establish database connection
    $dbh = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (Exception $e) {
    error_log("Database connection error: " . $e->getMessage());
    die("Database connection failed. Please check the logs.");
}
?>
EOF

# Create Apache virtual host configuration
cat > /etc/httpd/conf.d/olms.conf << 'EOF'
<VirtualHost *:80>
    DocumentRoot /var/www/html/olms
    ServerName localhost
    
    <Directory /var/www/html/olms>
        AllowOverride All
        Require all granted
    </Directory>
    
    # Security headers
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options DENY
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains; preload"
    Header always set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'"
    
    # Hide server information
    ServerTokens Prod
    ServerSignature Off
</VirtualHost>
EOF

# Enable mod_headers for security headers
echo "LoadModule headers_module modules/mod_headers.so" >> /etc/httpd/conf/httpd.conf

# Configure CloudWatch agent
cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json << 'EOF'
{
    "logs": {
        "logs_collected": {
            "files": {
                "collect_list": [
                    {
                        "file_path": "/var/log/httpd/access_log",
                        "log_group_name": "/aws/ec2/olms/apache/access",
                        "log_stream_name": "{instance_id}"
                    },
                    {
                        "file_path": "/var/log/httpd/error_log",
                        "log_group_name": "/aws/ec2/olms/apache/error",
                        "log_stream_name": "{instance_id}"
                    }
                ]
            }
        }
    },
    "metrics": {
        "namespace": "OLMS/EC2",
        "metrics_collected": {
            "cpu": {
                "measurement": [
                    "cpu_usage_idle",
                    "cpu_usage_iowait",
                    "cpu_usage_user",
                    "cpu_usage_system"
                ],
                "metrics_collection_interval": 60
            },
            "disk": {
                "measurement": [
                    "used_percent"
                ],
                "metrics_collection_interval": 60,
                "resources": [
                    "*"
                ]
            },
            "mem": {
                "measurement": [
                    "mem_used_percent"
                ],
                "metrics_collection_interval": 60
            }
        }
    }
}
EOF

# Start CloudWatch agent
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json -s

# Restart Apache
systemctl restart httpd

# Create a simple health check endpoint
cat > /var/www/html/olms/health.php << 'EOF'
<?php
// Simple health check endpoint
header('Content-Type: application/json');

$health = array(
    'status' => 'healthy',
    'timestamp' => date('Y-m-d H:i:s'),
    'server' => gethostname()
);

// Check database connection
try {
    include_once 'config/aws_config.php';
    $health['database'] = 'connected';
} catch (Exception $e) {
    $health['database'] = 'error';
    $health['status'] = 'unhealthy';
}

echo json_encode($health);
?>
EOF

# Set up log rotation for application logs
cat > /etc/logrotate.d/olms << 'EOF'
/var/log/olms/*.log {
    daily
    missingok
    rotate 7
    compress
    delaycompress
    notifempty
    create 644 apache apache
}
EOF

# Create application log directory
mkdir -p /var/log/olms
chown apache:apache /var/log/olms

echo "OLMS web server setup completed successfully"

